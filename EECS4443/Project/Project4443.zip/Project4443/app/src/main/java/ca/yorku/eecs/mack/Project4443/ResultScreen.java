package ca.yorku.eecs.mack.Project4443;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Log;
import android.view.Surface;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.ToggleButton;

public class ResultScreen extends Activity {

    final static String MYDEBUG = "MYDEBUG"; // for Log.i messages

    String errors, timeTaken;
    TextView myErrors, myTimeTaken;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Log.i(MYDEBUG, "Got here! (DemoTiltBallActivity - onCreate)");

        Bundle b = getIntent().getExtras();
        errors = "Errors: " + b.getInt("errors");
        timeTaken = "Time Taken: " + b.getFloat("time") + "s";
        setContentView(R.layout.resultscreen);
        init();

    }

    private void init() {
        myErrors = (TextView) findViewById(R.id.errors);
        myTimeTaken = (TextView) findViewById(R.id.timetaken);

        myErrors.setText(errors);
        myTimeTaken.setText(timeTaken);
    }

    public void clickBackToMenu(View view)
    {   // start experiment activity
        DemoTiltBallSetup.fa.finish();
        Intent i = new Intent(getApplicationContext(), DemoTiltBallSetup.class);
        startActivity(i);
        finish();

        // comment out (return to setup after clicking BACK in main activity
        //finish();
    }
}