package ca.yorku.eecs.mack.Project4443;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.util.Log;

public class DemoTiltBallSetup extends Activity
{
	final static String[] MODES = { "Button Mode", "Swipe Mode" };

	final static String MYDEBUG = "MYDEBUG";

	Spinner gameMode;
	String chosenMode;

	// Activity tracker
	public static Activity fa;

	// called when the activity is first created
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);

		Log.i(MYDEBUG, "Got here! (DemoTiltBallSetup - onCreate)");

		fa = this;

		setContentView(R.layout.setup);

		gameMode = (Spinner) findViewById(R.id.gameModeControl);
		ArrayAdapter<CharSequence> adapter1 = new ArrayAdapter<CharSequence>(this, R.layout.spinnerstyle, MODES);
		gameMode.setAdapter(adapter1);
		gameMode.setSelection(0); // "button" default
	}

	// called when the "OK" button is tapped
	public void clickOK(View view)
	{
		// get user's choices...
		String selectedMode = (String) gameMode.getSelectedItem();


		// bundle up parameters to pass on to activity
		Bundle b = new Bundle();
		b.putString("selectedMode", selectedMode);

		// start experiment activity
		Intent i = new Intent(getApplicationContext(), DemoTiltBallActivity.class);
		i.putExtras(b);
		startActivity(i);

		// comment out (return to setup after clicking BACK in main activity
		//finish();
	}

	/** Called when the "Exit" button is pressed. */
	public void clickExit(View view)
	{
		super.onDestroy(); // cleanup
		this.finish(); // terminate
	}
}