package ca.yorku.eecs.mack.Project4443;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Bundle;
import android.os.Vibrator;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;
import android.view.View.OnTouchListener;
import android.view.GestureDetector.SimpleOnGestureListener;
import java.util.Random;


public class DemoTiltBallActivity extends Activity implements OnTouchListener
{
    final static String MYDEBUG = "MYDEBUG"; // for Log.i messages

    //V: Stuff I am adding STARTS HERE-----------------FINAL VERSION---------------------------
    TextView firstDoor;
    TextView secondDoor;
    TextView thirdDoor;
    TextView fourthDoor;
    TextView fifthDoor;
    TextView firstDoorIndicator;
    TextView secondDoorIndicator;
    TextView thirdDoorIndicator;
    TextView fourthDoorIndicator;
    TextView fifthDoorIndicator;
    ImageButton leftButton;
    Button enterButton;
    ImageButton rightButton;
    TextView enterDoor;



    //door indicator
    int doorNum = 3;
    int errorCount = 0;

    //random door to enter
    int min = 1;
    int max = 5;
    int doorEnter = new Random().nextInt((max-min)+1)+min;

    //Number of levels
    //Every time the user hits enter they move to the next level so increment the level counter by one there
    int levelCount = 0;

    //We will start the timer upon the first button hit
    long startTime = 0;
    long endTime = 0;
    float totalTime = 0;
    //float displayTime = 0;
    //We can use the fact that the time holding variables start off at 0 as a flag itself

    //Used for swipe based
    LinearLayout screen;
    private GestureDetector gestureDetector;

    String gameMode;

    //Used for user feedback
    Vibrator vib;
    ToneGenerator toneGenerator;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);





        Log.i(MYDEBUG, "Got here! (DemoTiltBallActivity - onCreate)");

        Bundle b = getIntent().getExtras();
        gameMode = b.getString("selectedMode");

        if (gameMode.equals("Button Mode"))
            setContentView(R.layout.buttongamescreen);
        else if (gameMode.equals("Swipe Mode")) {
            setContentView(R.layout.swipegamescreen);
            screen = (LinearLayout) findViewById(R.id.screen);
            screen.setOnTouchListener(this);
            gestureDetector = new GestureDetector(this, new GestureListener());




        }
        init();


    }

    private void init() {
        firstDoor = (TextView) findViewById(R.id.firstDoor);
        secondDoor = (TextView) findViewById(R.id.secondDoor);
        thirdDoor = (TextView) findViewById(R.id.thirdDoor);
        fourthDoor = (TextView) findViewById(R.id.fourthDoor);
        fifthDoor = (TextView) findViewById(R.id.fifthDoor);
        firstDoorIndicator = (TextView) findViewById(R.id.firstDoorIndicator);
        secondDoorIndicator = (TextView) findViewById(R.id.secondDoorIndicator);
        thirdDoorIndicator = (TextView) findViewById(R.id.thirdDoorIndicator);
        fourthDoorIndicator = (TextView) findViewById(R.id.fourthDoorIndicator);
        fifthDoorIndicator = (TextView) findViewById(R.id.fifthDoorIndicator);
        if(gameMode.equals("Button Mode"))
        {
            leftButton = (ImageButton) findViewById(R.id.leftButton);
            enterButton = (Button) findViewById(R.id.enterButton);
            rightButton = (ImageButton) findViewById(R.id.rightButton);
        }

        enterDoor = (TextView) findViewById(R.id.enterDoor);

        //question string
        String questionString = "Enter Door " +doorEnter;



        enterDoor.setText(""+questionString);

        vib = (Vibrator)this.getSystemService(Context.VIBRATOR_SERVICE);
        toneGenerator = new ToneGenerator(AudioManager.STREAM_MUSIC, 100); // beep sound
    }

    // handle button clicks
    public void buttonClick(View v) {

        //Game only works if the user has not completed all of the levels
        if (levelCount != 10) {
            //right button
            if (v == rightButton) {
                toneGenerator.startTone(ToneGenerator.TONE_CDMA_PIP, 150); // beep sound

                //if this is the first button hit, grab the time
                if (startTime == 0) {
                    startTime = System.nanoTime();
                }

                //if the user is not already at the rightmost door, let them go one more to the right
                if (doorNum != 5) {
                    doorNum++;
                    updateIndicator();
                }

            }

            //left button
            if (v == leftButton) {
                toneGenerator.startTone(ToneGenerator.TONE_CDMA_PIP, 150); // beep sound

                //if this is the first button hit, grab the time
                if (startTime == 0) {
                    startTime = System.nanoTime();
                }

                //if the user is not at the leftmost door, let them go one more to the left
                if (doorNum != 1) {
                    doorNum--;
                    updateIndicator();
                }

            }

            //enter button
            if (v == enterButton) {



                vib.vibrate(50); // 50 ms vibrotactile pulse
                toneGenerator.startTone(ToneGenerator.TONE_CDMA_PIP, 150); // beep sound



                //if this is the first button hit, grab the time
                if (startTime == 0) {
                    startTime = System.nanoTime();
                }

                //Increase error count if the user entered the wrong door
                if (doorNum != doorEnter) {
                    //Increase error count if the user selects the wrong door
                    errorCount++;
                }


                //Increase the level counter
                levelCount++;
                //Show the user the next target
                nextTarget();
            }
        }
    }

    public void updateIndicator()
    {
        if(doorNum == 1)
        {
            firstDoorIndicator.setBackgroundColor(Color.rgb(255,0,0));
            secondDoorIndicator.setBackgroundColor(Color.rgb(255,255,255));
            thirdDoorIndicator.setBackgroundColor(Color.rgb(255,255,255));
            fourthDoorIndicator.setBackgroundColor(Color.rgb(255,255,255));
            fifthDoorIndicator.setBackgroundColor(Color.rgb(255,255,255));
        }
        if(doorNum == 2)
        {
            firstDoorIndicator.setBackgroundColor(Color.rgb(255,255,255));
            secondDoorIndicator.setBackgroundColor(Color.rgb(255,0,0));
            thirdDoorIndicator.setBackgroundColor(Color.rgb(255,255,255));
            fourthDoorIndicator.setBackgroundColor(Color.rgb(255,255,255));
            fifthDoorIndicator.setBackgroundColor(Color.rgb(255,255,255));
        }
        if(doorNum == 3)
        {
            firstDoorIndicator.setBackgroundColor(Color.rgb(255,255,255));
            secondDoorIndicator.setBackgroundColor(Color.rgb(255,255,255));
            thirdDoorIndicator.setBackgroundColor(Color.rgb(255,0,0));
            fourthDoorIndicator.setBackgroundColor(Color.rgb(255,255,255));
            fifthDoorIndicator.setBackgroundColor(Color.rgb(255,255,255));
        }
        if(doorNum == 4)
        {
            firstDoorIndicator.setBackgroundColor(Color.rgb(255,255,255));
            secondDoorIndicator.setBackgroundColor(Color.rgb(255,255,255));
            thirdDoorIndicator.setBackgroundColor(Color.rgb(255,255,255));
            fourthDoorIndicator.setBackgroundColor(Color.rgb(255,0,0));
            fifthDoorIndicator.setBackgroundColor(Color.rgb(255,255,255));
        }
        if(doorNum == 5)
        {
            firstDoorIndicator.setBackgroundColor(Color.rgb(255,255,255));
            secondDoorIndicator.setBackgroundColor(Color.rgb(255,255,255));
            thirdDoorIndicator.setBackgroundColor(Color.rgb(255,255,255));
            fourthDoorIndicator.setBackgroundColor(Color.rgb(255,255,255));
            fifthDoorIndicator.setBackgroundColor(Color.rgb(255,0,0));
        }
    }

    public void nextTarget()
    {
        if(levelCount != 10)
        {
            doorEnter = new Random().nextInt((max-min)+1)+min;
        }
        else if(levelCount == 10)
        {
            endTime = System.nanoTime();
            totalTime = (endTime - startTime) / 1000000000f;
            //displayTime = (float) Math.round(totalTime)/100;
            //totalTime = Math.round(totalTime);

            Bundle b = new Bundle();
            b.putInt("errors", errorCount);
            b.putFloat("time", totalTime);

            Intent i = new Intent(getApplicationContext(), ResultScreen.class);
            i.putExtras(b);
            startActivity(i);
            finish();
        }


        String questionString = "Enter Door  " + doorEnter;
        enterDoor.setText(""+questionString);
    }

    @Override
    public boolean onTouch(View v, MotionEvent event) {
        return gestureDetector.onTouchEvent(event);
    }

    private final class GestureListener extends SimpleOnGestureListener {

        private static final int SWIPE_THRESHOLD = 100;
        private static final int SWIPE_VELOCITY_THRESHOLD = 100;

        @Override
        public boolean onDown(MotionEvent e) {
            return true;
        }

        @Override
        public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
            boolean result = false;
            try {
                float diffY = e2.getY() - e1.getY();
                float diffX = e2.getX() - e1.getX();
                if (Math.abs(diffX) > Math.abs(diffY)) {
                    if (Math.abs(diffX) > SWIPE_THRESHOLD && Math.abs(velocityX) > SWIPE_VELOCITY_THRESHOLD) {
                        if (diffX > 0) {
                            onSwipeRight();
                        } else {
                            onSwipeLeft();
                        }
                        result = true;
                    }
                }
                else if (Math.abs(diffY) > SWIPE_THRESHOLD && Math.abs(velocityY) > SWIPE_VELOCITY_THRESHOLD) {
                    if (diffY > 0) {

                    } else {
                        onSwipeTop();
                    }
                    result = true;
                }
            } catch (Exception exception) {
                exception.printStackTrace();
            }
            return result;
        }
    }

    public void onSwipeRight() {
        if(levelCount != 10) {
            toneGenerator.startTone(ToneGenerator.TONE_CDMA_PIP, 150); // beep sound

            //if this is the first button hit, grab the time
            if (startTime == 0) {
                startTime = System.nanoTime();
            }

            //if the user is not already at the rightmost door, let them go one more to the right
            if (doorNum != 5) {
                doorNum++;
                updateIndicator();
            }
        }
    }

    public void onSwipeLeft() {
        if(levelCount != 10) {
            toneGenerator.startTone(ToneGenerator.TONE_CDMA_PIP, 150); // beep sound

            //if this is the first button hit, grab the time
            if(startTime == 0)
            {
                startTime = System.nanoTime();
            }

            //if the user is not at the leftmost door, let them go one more to the left
            if(doorNum != 1)
            {
                doorNum--;
                updateIndicator();
            }
        }
    }

    public void onSwipeTop() {
        if(levelCount != 10) {
            vib.vibrate(50); // 50 ms vibrotactile pulse
            toneGenerator.startTone(ToneGenerator.TONE_CDMA_PIP, 150); // beep sound
            
            if (startTime == 0) {
                startTime = System.nanoTime();
            }

            //Increase error count if the user entered the wrong door
            if (doorNum != doorEnter) {
                //Increase error count if the user selects the wrong door
                errorCount++;
            }
            //Increase the level counter
            levelCount++;
            //Show the user the next target
            nextTarget();
        }
    }

}
